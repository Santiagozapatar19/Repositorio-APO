package model;

public enum TipoApartamento {
    PENTHOUSE,
    REGULAR,
    FIRST_FLOOR
}
